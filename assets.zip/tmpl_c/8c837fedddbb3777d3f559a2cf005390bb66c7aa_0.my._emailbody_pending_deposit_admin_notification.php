<?php /* Smarty version 3.1.27, created on 2023-07-08 16:41:45
         compiled from "my:_emailbody_pending_deposit_admin_notification" */ ?>
<?php
/*%%SmartyHeaderCode:101799476964a991c93f1480_72912616%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c837fedddbb3777d3f559a2cf005390bb66c7aa' => 
    array (
      0 => 'my:_emailbody_pending_deposit_admin_notification',
      1 => 1688834505,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '101799476964a991c93f1480_72912616',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64a991c93ff6b1_62354696',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64a991c93ff6b1_62354696')) {
function content_64a991c93ff6b1_62354696 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '101799476964a991c93f1480_72912616';
?>
User #username# save deposit $#amount# of #currency# to #plan#.

#fields#<?php }
}
?>