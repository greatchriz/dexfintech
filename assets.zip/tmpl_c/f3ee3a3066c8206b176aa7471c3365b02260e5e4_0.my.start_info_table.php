<?php /* Smarty version 3.1.27, created on 2023-07-09 05:52:39
         compiled from "my:start_info_table" */ ?>
<?php
/*%%SmartyHeaderCode:145595172764aa4b27396a72_72439630%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f3ee3a3066c8206b176aa7471c3365b02260e5e4' => 
    array (
      0 => 'my:start_info_table',
      1 => 1688881959,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '145595172764aa4b27396a72_72439630',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aa4b27397528_92471498',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aa4b27397528_92471498')) {
function content_64aa4b27397528_92471498 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '145595172764aa4b27396a72_72439630';
?>
<div class="alert alert-warning"><?php }
}
?>