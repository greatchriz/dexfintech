<?php /* Smarty version 3.1.27, created on 2023-07-09 05:55:06
         compiled from "my:admin_footer" */ ?>
<?php
/*%%SmartyHeaderCode:63034425264aa4bba8b9529_19968134%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c2b20d3aaeacf873df3ad2515e6faace0f837811' => 
    array (
      0 => 'my:admin_footer',
      1 => 1688882106,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '63034425264aa4bba8b9529_19968134',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aa4bba8ba883_16134305',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aa4bba8ba883_16134305')) {
function content_64aa4bba8ba883_16134305 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '63034425264aa4bba8b9529_19968134';
?>
 </td> </tr> </table> <!-- Main: END --> 
 </td> </tr> </table> </td> </tr> </table> </td> </tr> <tr> <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">Powered with HYIP Manager. <a href=http://www.goldcoders.com class="forCopyright">GoldCoders.com</a></div></td> 
 </tr> </table> </center></body> </html> <?php }
}
?>