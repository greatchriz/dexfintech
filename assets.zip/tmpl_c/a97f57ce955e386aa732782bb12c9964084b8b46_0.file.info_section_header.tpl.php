<?php /* Smarty version 3.1.27, created on 2023-07-06 18:16:40
         compiled from "/home/dexfisce/public_html/tmpl/info_section_header.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:194316362664a7050889e315_70708436%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a97f57ce955e386aa732782bb12c9964084b8b46' => 
    array (
      0 => '/home/dexfisce/public_html/tmpl/info_section_header.tpl',
      1 => 1687587446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '194316362664a7050889e315_70708436',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64a7050889ff20_77937927',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64a7050889ff20_77937927')) {
function content_64a7050889ff20_77937927 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '194316362664a7050889e315_70708436';
?>
<section class="relative md:py-24 py-16">
	<div class="container relative">
		<div class="grid grid-cols-1 pb-8 text-center">
			<h3 class="mb-4 md:text-3xl md:leading-normal text-2xl leading-normal font-semibold">stats</h3>

			<p class="text-slate-400 max-w-xl mx-auto">Discover the Perfect Investment Plan to Maximize Your Returns.
			</p>
		</div>
		<!--end grid-->

			<div class="grid grid-cols-1 gap-[30px] mt-10">
				<div class="tiny-three-item"><?php }
}
?>