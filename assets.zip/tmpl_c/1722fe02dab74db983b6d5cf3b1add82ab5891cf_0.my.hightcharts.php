<?php /* Smarty version 3.1.27, created on 2023-07-09 05:46:39
         compiled from "my:hightcharts" */ ?>
<?php
/*%%SmartyHeaderCode:145740601564aa49bf24e383_83032952%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1722fe02dab74db983b6d5cf3b1add82ab5891cf' => 
    array (
      0 => 'my:hightcharts',
      1 => 1688881599,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '145740601564aa49bf24e383_83032952',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aa49bf24f313_77389688',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aa49bf24f313_77389688')) {
function content_64aa49bf24f313_77389688 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '145740601564aa49bf24e383_83032952';
?>
 <?php }
}
?>