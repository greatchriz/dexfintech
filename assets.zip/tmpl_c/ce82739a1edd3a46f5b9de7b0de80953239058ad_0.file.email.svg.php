<?php /* Smarty version 3.1.27, created on 2023-07-09 18:23:01
         compiled from "/home/dexfisce/public_html/images/svg/form/email.svg" */ ?>
<?php
/*%%SmartyHeaderCode:141123941764aafb0596de02_88246241%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce82739a1edd3a46f5b9de7b0de80953239058ad' => 
    array (
      0 => '/home/dexfisce/public_html/images/svg/form/email.svg',
      1 => 1685852428,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '141123941764aafb0596de02_88246241',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aafb05970565_62656626',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aafb05970565_62656626')) {
function content_64aafb05970565_62656626 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '141123941764aafb0596de02_88246241';
?>
<svg
    xmlns="http://www.w3.org/2000/svg"
    class="h-5 w-5 transition-colors duration-200"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
>
    <path
        stroke-linecap="round"
        stroke-linejoin="round"
        stroke-width="1.5"
        d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
    ></path>
</svg><?php }
}
?>