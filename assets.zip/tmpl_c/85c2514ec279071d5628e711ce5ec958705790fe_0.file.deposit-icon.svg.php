<?php /* Smarty version 3.1.27, created on 2023-07-09 15:33:59
         compiled from "/home/dexfisce/public_html/images/svg/deposit-icon.svg" */ ?>
<?php
/*%%SmartyHeaderCode:43522494664aad3673380f1_46036704%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '85c2514ec279071d5628e711ce5ec958705790fe' => 
    array (
      0 => '/home/dexfisce/public_html/images/svg/deposit-icon.svg',
      1 => 1686628758,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '43522494664aad3673380f1_46036704',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aad36733ad73_35964788',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aad36733ad73_35964788')) {
function content_64aad36733ad73_35964788 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '43522494664aad3673380f1_46036704';
?>
<svg
    class="h-7 w-7"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
>
    <g
        id="SVGRepo_bgCarrier"
        stroke-width="0"
    ></g>
    <g
        id="SVGRepo_tracerCarrier"
        stroke-linecap="round"
        stroke-linejoin="round"
    ></g>
    <g id="SVGRepo_iconCarrier">
        <g opacity="0.4">
            <path
                d="M9.5 13.7502C9.5 14.7202 10.25 15.5002 11.17 15.5002H13.05C13.85 15.5002 14.5 14.8202 14.5 13.9702C14.5 13.0602 14.1 12.7302 13.51 12.5202L10.5 11.4702C9.91 11.2602 9.51001 10.9402 9.51001 10.0202C9.51001 9.18023 10.16 8.49023 10.96 8.49023H12.84C13.76 8.49023 14.51 9.27023 14.51 10.2402"
                stroke="#4f46e5"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
            ></path>
            <path
                d="M12 7.5V16.5"
                stroke="#4f46e5"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
            ></path>
        </g>
        <path
            d="M22 12C22 17.52 17.52 22 12 22C6.48 22 2 17.52 2 12C2 6.48 6.48 2 12 2"
            stroke="#4f46e5"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        ></path>
        <path
            d="M22 6V2H18"
            stroke="#4f46e5"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        ></path>
        <path
            d="M17 7L22 2"
            stroke="#4f46e5"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        ></path>
    </g>
</svg>
<?php }
}
?>