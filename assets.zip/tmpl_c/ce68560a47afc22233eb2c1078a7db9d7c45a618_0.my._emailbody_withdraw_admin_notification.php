<?php /* Smarty version 3.1.27, created on 2023-07-08 19:09:24
         compiled from "my:_emailbody_withdraw_admin_notification" */ ?>
<?php
/*%%SmartyHeaderCode:157529430264a9b464f1e803_32602324%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce68560a47afc22233eb2c1078a7db9d7c45a618' => 
    array (
      0 => 'my:_emailbody_withdraw_admin_notification',
      1 => 1688843364,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '157529430264a9b464f1e803_32602324',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64a9b464f205d0_06832916',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64a9b464f205d0_06832916')) {
function content_64a9b464f205d0_06832916 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '157529430264a9b464f1e803_32602324';
?>
User #username# received $#amount# to #currency# account #account#. Batch is #batch#.<?php }
}
?>