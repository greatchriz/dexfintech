<?php /* Smarty version 3.1.27, created on 2023-07-09 15:33:59
         compiled from "/home/dexfisce/public_html/images/svg/logout-icon.svg" */ ?>
<?php
/*%%SmartyHeaderCode:126502415064aad36736ca75_71387836%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c409a5d25c9ca59cb79a181f603b5af698d2097e' => 
    array (
      0 => '/home/dexfisce/public_html/images/svg/logout-icon.svg',
      1 => 1686629110,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '126502415064aad36736ca75_71387836',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aad36736fd16_49243295',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aad36736fd16_49243295')) {
function content_64aad36736fd16_49243295 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '126502415064aad36736ca75_71387836';
?>
<svg
    class="h-7 w-7"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
>
    <g
        id="SVGRepo_bgCarrier"
        stroke-width="0"
    ></g>
    <g
        id="SVGRepo_tracerCarrier"
        stroke-linecap="round"
        stroke-linejoin="round"
    ></g>
    <g id="SVGRepo_iconCarrier">
        <path
            d="M21 12L13 12"
            stroke="#4f46e5"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
        ></path>
        <path
            d="M18 15L20.913 12.087V12.087C20.961 12.039 20.961 11.961 20.913 11.913V11.913L18 9"
            stroke="#4f46e5"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
        ></path>
        <path
            d="M16 5V4.5V4.5C16 3.67157 15.3284 3 14.5 3H5C3.89543 3 3 3.89543 3 5V19C3 20.1046 3.89543 21 5 21H14.5C15.3284 21 16 20.3284 16 19.5V19.5V19"
            stroke="#4f46e5"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
        ></path>
    </g>
</svg>
<?php }
}
?>