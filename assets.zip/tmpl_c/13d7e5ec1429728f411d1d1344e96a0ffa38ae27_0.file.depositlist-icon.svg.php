<?php /* Smarty version 3.1.27, created on 2023-07-09 15:33:59
         compiled from "/home/dexfisce/public_html/images/svg/depositlist-icon.svg" */ ?>
<?php
/*%%SmartyHeaderCode:44871236764aad36733e442_03374415%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '13d7e5ec1429728f411d1d1344e96a0ffa38ae27' => 
    array (
      0 => '/home/dexfisce/public_html/images/svg/depositlist-icon.svg',
      1 => 1686616998,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '44871236764aad36733e442_03374415',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aad367340317_07120475',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aad367340317_07120475')) {
function content_64aad367340317_07120475 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '44871236764aad36733e442_03374415';
?>
<svg
    class="h-7 w-7"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
>
    <g
        id="SVGRepo_bgCarrier"
        stroke-width="0"
    ></g>
    <g
        id="SVGRepo_tracerCarrier"
        stroke-linecap="round"
        stroke-linejoin="round"
    ></g>
    <g id="SVGRepo_iconCarrier">
        <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M5 7C5 6.44772 5.44772 6 6 6H18C18.5523 6 19 6.44772 19 7C19 7.55228 18.5523 8 18 8H6C5.44772 8 5 7.55228 5 7ZM5 12C5 11.4477 5.44772 11 6 11H18C18.5523 11 19 11.4477 19 12C19 12.5523 18.5523 13 18 13H6C5.44772 13 5 12.5523 5 12ZM5 17C5 16.4477 5.44772 16 6 16H18C18.5523 16 19 16.4477 19 17C19 17.5523 18.5523 18 18 18H6C5.44772 18 5 17.5523 5 17Z"
            fill="#4f46e5"
        ></path>
    </g>
</svg>
<?php }
}
?>