<?php /* Smarty version 3.1.27, created on 2023-07-06 18:16:13
         compiled from "/home/dexfisce/public_html/tmpl/custom/services.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:187304677864a704ed089458_02725787%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '83602a593dc848e386dfabb01d9bc4c7ca836395' => 
    array (
      0 => '/home/dexfisce/public_html/tmpl/custom/services.tpl',
      1 => 1686639116,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '187304677864a704ed089458_02725787',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64a704ed116b32_15574851',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64a704ed116b32_15574851')) {
function content_64a704ed116b32_15574851 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '187304677864a704ed089458_02725787';
echo $_smarty_tpl->getSubTemplate ("front/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<!-- Start Hero -->
<section
    class="relative table w-full py-36 lg:py-44 bg-[url('../../assets/images/services.jpg')] bg-no-repeat bg-center bg-cover"
>
    <div class="absolute inset-0 bg-black opacity-75"></div>
    <div class="container relative">
        <div class="grid grid-cols-1 pb-8 text-center mt-10">
            <h5 class="text-white/50 text-lg font-medium">What We Offer ?</h5>
            <h3 class="mt-2 md:text-4xl text-3xl md:leading-normal leading-normal font-medium text-white">Our
                Services</h3>
        </div>
        <!--end grid-->
    </div>
    <!--end container-->

    <div class="absolute text-center z-10 bottom-5 start-0 end-0 mx-3">
        <ul class="breadcrumb tracking-[0.5px] breadcrumb-light mb-0 inline-block">
            <li
                class="inline breadcrumb-item uppercase text-[13px] font-bold duration-500 ease-in-out text-white/50 hover:text-white">
                <a href="index.html">Techwind</a>
            </li>
            <li
                class="inline breadcrumb-item uppercase text-[13px] font-bold duration-500 ease-in-out text-white/50 hover:text-white">
                <a href="">Company</a>
            </li>
            <li
                class="inline breadcrumb-item uppercase text-[13px] font-bold duration-500 ease-in-out text-white"
                aria-current="page"
            >Services</li>
        </ul>
    </div>
</section>
<!--end section-->
<div class="relative">
    <div
        class="shape absolute sm:-bottom-px -bottom-[2px] start-0 end-0 overflow-hidden z-1 text-white dark:text-slate-900">
        <svg
            class="w-full h-auto"
            viewBox="0 0 2880 48"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z"
                fill="currentColor"
            ></path>
        </svg>
    </div>
</div>
<!-- End Hero -->

<!-- Start Section-->
<section class="relative md:py-24 py-16">
    <div class="container relative">
        <div class="grid grid-cols-1 lg:grid-cols-3 md:grid-cols-2 gap-[30px]">
            <div
                class="p-6 hover:shadow-xl hover:shadow-gray-100 dark:hover:shadow-gray-800 transition duration-500 rounded-2xl mt-6 text-center">
                <div
                    class="w-20 h-20 bg-indigo-600/5 text-indigo-600 rounded-xl text-3xl flex align-middle justify-center items-center shadow-sm dark:shadow-gray-800 mx-auto">
                    <i class="uil uil-airplay"></i>
                </div>

                <div class="content mt-7">
                    <a
                        href="page-services.html"
                        class="title h5 text-lg font-medium hover:text-indigo-600"
                    >UX / UI Design</a>
                    <p class="text-slate-400 mt-3">The phrasal sequence of the is now so that many campaign and
                        benefit</p>

                    <div class="mt-5">
                        <a
                            href="page-services.html"
                            class="btn btn-link text-indigo-600 hover:text-indigo-600 after:bg-indigo-600 duration-500 ease-in-out"
                        >Read More <i class="uil uil-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div
                class="p-6 shadow-xl shadow-gray-100 dark:shadow-gray-800 transition duration-500 rounded-2xl mt-6 text-center">
                <div
                    class="w-20 h-20 bg-indigo-600/5 text-indigo-600 rounded-xl text-3xl flex align-middle justify-center items-center shadow-sm dark:shadow-gray-800 mx-auto">
                    <i class="uil uil-shutter"></i>
                </div>

                <div class="content mt-7">
                    <a
                        href="page-services.html"
                        class="title h5 text-lg font-medium hover:text-indigo-600"
                    >IOS App Designer</a>
                    <p class="text-slate-400 mt-3">The phrasal sequence of the is now so that many campaign and
                        benefit</p>

                    <div class="mt-5">
                        <a
                            href="page-services.html"
                            class="btn btn-link text-indigo-600 hover:text-indigo-600 after:bg-indigo-600 duration-500 ease-in-out"
                        >Read More <i class="uil uil-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div
                class="p-6 hover:shadow-xl hover:shadow-gray-100 dark:hover:shadow-gray-800 transition duration-500 rounded-2xl mt-6 text-center">
                <div
                    class="w-20 h-20 bg-indigo-600/5 text-indigo-600 rounded-xl text-3xl flex align-middle justify-center items-center shadow-sm dark:shadow-gray-800 mx-auto">
                    <i class="uil uil-camera-plus"></i>
                </div>

                <div class="content mt-7">
                    <a
                        href="page-services.html"
                        class="title h5 text-lg font-medium hover:text-indigo-600"
                    >Photography</a>
                    <p class="text-slate-400 mt-3">The phrasal sequence of the is now so that many campaign and
                        benefit</p>

                    <div class="mt-5">
                        <a
                            href="page-services.html"
                            class="btn btn-link text-indigo-600 hover:text-indigo-600 after:bg-indigo-600 duration-500 ease-in-out"
                        >Read More <i class="uil uil-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div
                class="p-6 shadow-xl shadow-gray-100 dark:shadow-gray-800 transition duration-500 rounded-2xl mt-6 text-center">
                <div
                    class="w-20 h-20 bg-indigo-600/5 text-indigo-600 rounded-xl text-3xl flex align-middle justify-center items-center shadow-sm dark:shadow-gray-800 mx-auto">
                    <i class="uil uil-flower"></i>
                </div>

                <div class="content mt-7">
                    <a
                        href="page-services.html"
                        class="title h5 text-lg font-medium hover:text-indigo-600"
                    >Graphic Designer</a>
                    <p class="text-slate-400 mt-3">The phrasal sequence of the is now so that many campaign and
                        benefit</p>

                    <div class="mt-5">
                        <a
                            href="page-services.html"
                            class="btn btn-link text-indigo-600 hover:text-indigo-600 after:bg-indigo-600 duration-500 ease-in-out"
                        >Read More <i class="uil uil-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div
                class="p-6 hover:shadow-xl hover:shadow-gray-100 dark:hover:shadow-gray-800 transition duration-500 rounded-2xl mt-6 text-center">
                <div
                    class="w-20 h-20 bg-indigo-600/5 text-indigo-600 rounded-xl text-3xl flex align-middle justify-center items-center shadow-sm dark:shadow-gray-800 mx-auto">
                    <i class="uil uil-cog"></i>
                </div>

                <div class="content mt-7">
                    <a
                        href="page-services.html"
                        class="title h5 text-lg font-medium hover:text-indigo-600"
                    >Web Security</a>
                    <p class="text-slate-400 mt-3">The phrasal sequence of the is now so that many campaign and
                        benefit</p>

                    <div class="mt-5">
                        <a
                            href="page-services.html"
                            class="btn btn-link text-indigo-600 hover:text-indigo-600 after:bg-indigo-600 duration-500 ease-in-out"
                        >Read More <i class="uil uil-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div
                class="p-6 shadow-xl shadow-gray-100 dark:shadow-gray-800 transition duration-500 rounded-2xl mt-6 text-center">
                <div
                    class="w-20 h-20 bg-indigo-600/5 text-indigo-600 rounded-xl text-3xl flex align-middle justify-center items-center shadow-sm dark:shadow-gray-800 mx-auto">
                    <i class="uil uil-comment"></i>
                </div>

                <div class="content mt-7">
                    <a
                        href="page-services.html"
                        class="title h5 text-lg font-medium hover:text-indigo-600"
                    >24/7 Support</a>
                    <p class="text-slate-400 mt-3">The phrasal sequence of the is now so that many campaign and
                        benefit</p>

                    <div class="mt-5">
                        <a
                            href="page-services.html"
                            class="btn btn-link text-indigo-600 hover:text-indigo-600 after:bg-indigo-600 duration-500 ease-in-out"
                        >Read More <i class="uil uil-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!--end grid-->
    </div>
    <!--end container-->

    <div class="container relative md:mt-24 mt-16">
        <div class="grid grid-cols-1 pb-8 items-end">
            <h3 class="mb-4 md:text-3xl md:leading-normal text-2xl leading-normal font-semibold">Latest Projects
                & Works</h3>
            <p class="text-slate-400 max-w-xl">Explore and learn more about everything from machine learning and
                global payments to scaling your team.</p>
        </div>
        <!--end grid-->
    </div>
    <!--end container-->

    <div class="container-fluid relative mt-8">
        <div class="grid grid-cols-1 mt-8">
            <div class="tiny-six-item">
                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/1.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/1.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/2.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/2.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/3.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/3.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/4.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/4.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/5.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/5.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/6.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/6.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/7.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/7.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/8.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/8.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/9.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/9.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/20.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/20.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/21.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/21.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/22.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/22.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide">
                    <div class="group relative block overflow-hidden rounded-md transition-all duration-500 mx-2">
                        <a
                            href="assets/images/portfolio/23.jpg"
                            class="lightbox transition-all duration-500 group-hover:scale-105"
                            title=""
                        >
                            <img
                                src="assets/images/portfolio/23.jpg"
                                class=""
                                alt="work-image"
                            >
                        </a>
                        <div
                            class="absolute -bottom-52 group-hover:bottom-2 start-2 end-2 transition-all duration-500 bg-white dark:bg-slate-900 p-4 rounded shadow dark:shadow-gray-800">
                            <a
                                href="portfolio-detail-two.html"
                                class="hover:text-indigo-600 text-lg transition duration-500 font-medium"
                            >Iphone mockup</a>
                            <h6 class="text-slate-400">Branding</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end container-->

    <div class="container relative md:mt-24 mt-16">
        <div class="grid grid-cols-1 pb-8 text-center">
            <h3 class="mb-4 md:text-3xl md:leading-normal text-2xl leading-normal font-semibold">What Our Users
                Say</h3>

            <p class="text-slate-400 max-w-xl mx-auto">Start working with Tailwind CSS that can provide
                everything you need to generate awareness, drive traffic, connect.</p>
        </div>
        <!--end grid-->

        <div class="grid grid-cols-1 mt-8">
            <div class="tiny-three-item">
                <div class="tiny-slide text-center">
                    <div class="customer-testi">
                        <div
                            class="content relative rounded shadow dark:shadow-gray-800 m-2 p-6 bg-white dark:bg-slate-900">
                            <i class="mdi mdi-format-quote-open mdi-48px text-indigo-600"></i>
                            <p class="text-slate-400">" It seems that only fragments of the original text remain
                                in the Lorem Ipsum texts used today. "</p>
                            <ul class="list-none mb-0 text-amber-400 mt-3">
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                            </ul>
                        </div>

                        <div class="text-center mt-5">
                            <img
                                src="assets/images/client/01.jpg"
                                class="h-14 w-14 rounded-full shadow-md mx-auto"
                                alt=""
                            >
                            <h6 class="mt-2 font-semibold">Calvin Carlo</h6>
                            <span class="text-slate-400 text-sm">Manager</span>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide text-center">
                    <div class="customer-testi">
                        <div
                            class="content relative rounded shadow dark:shadow-gray-800 m-2 p-6 bg-white dark:bg-slate-900">
                            <i class="mdi mdi-format-quote-open mdi-48px text-indigo-600"></i>
                            <p class="text-slate-400">" The most well-known dummy text is the 'Lorem Ipsum',
                                which is said to have originated in the 16th century. "</p>
                            <ul class="list-none mb-0 text-amber-400 mt-3">
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                            </ul>
                        </div>

                        <div class="text-center mt-5">
                            <img
                                src="assets/images/client/02.jpg"
                                class="h-14 w-14 rounded-full shadow-md mx-auto"
                                alt=""
                            >
                            <h6 class="mt-2 font-semibold">Christa Smith</h6>
                            <span class="text-slate-400 text-sm">Manager</span>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide text-center">
                    <div class="customer-testi">
                        <div
                            class="content relative rounded shadow dark:shadow-gray-800 m-2 p-6 bg-white dark:bg-slate-900">
                            <i class="mdi mdi-format-quote-open mdi-48px text-indigo-600"></i>
                            <p class="text-slate-400">" One disadvantage of Lorum Ipsum is that in Latin certain
                                letters appear more frequently than others. "</p>
                            <ul class="list-none mb-0 text-amber-400 mt-3">
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                            </ul>
                        </div>

                        <div class="text-center mt-5">
                            <img
                                src="assets/images/client/03.jpg"
                                class="h-14 w-14 rounded-full shadow-md mx-auto"
                                alt=""
                            >
                            <h6 class="mt-2 font-semibold">Jemina CLone</h6>
                            <span class="text-slate-400 text-sm">Manager</span>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide text-center">
                    <div class="customer-testi">
                        <div
                            class="content relative rounded shadow dark:shadow-gray-800 m-2 p-6 bg-white dark:bg-slate-900">
                            <i class="mdi mdi-format-quote-open mdi-48px text-indigo-600"></i>
                            <p class="text-slate-400">" Thus, Lorem Ipsum has only limited suitability as a
                                visual filler for German texts. "</p>
                            <ul class="list-none mb-0 text-amber-400 mt-3">
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                            </ul>
                        </div>

                        <div class="text-center mt-5">
                            <img
                                src="assets/images/client/04.jpg"
                                class="h-14 w-14 rounded-full shadow-md mx-auto"
                                alt=""
                            >
                            <h6 class="mt-2 font-semibold">Smith Vodka</h6>
                            <span class="text-slate-400 text-sm">Manager</span>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide text-center">
                    <div class="customer-testi">
                        <div
                            class="content relative rounded shadow dark:shadow-gray-800 m-2 p-6 bg-white dark:bg-slate-900">
                            <i class="mdi mdi-format-quote-open mdi-48px text-indigo-600"></i>
                            <p class="text-slate-400">" There is now an abundance of readable dummy texts. These
                                are usually used when a text is required. "</p>
                            <ul class="list-none mb-0 text-amber-400 mt-3">
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                            </ul>
                        </div>

                        <div class="text-center mt-5">
                            <img
                                src="assets/images/client/05.jpg"
                                class="h-14 w-14 rounded-full shadow-md mx-auto"
                                alt=""
                            >
                            <h6 class="mt-2 font-semibold">Cristino Murfi</h6>
                            <span class="text-slate-400 text-sm">Manager</span>
                        </div>
                    </div>
                </div>

                <div class="tiny-slide text-center">
                    <div class="customer-testi">
                        <div
                            class="content relative rounded shadow dark:shadow-gray-800 m-2 p-6 bg-white dark:bg-slate-900">
                            <i class="mdi mdi-format-quote-open mdi-48px text-indigo-600"></i>
                            <p class="text-slate-400">" According to most sources, Lorum Ipsum can be traced
                                back to a text composed by Cicero. "</p>
                            <ul class="list-none mb-0 text-amber-400 mt-3">
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                                <li class="inline"><i class="mdi mdi-star"></i></li>
                            </ul>
                        </div>

                        <div class="text-center mt-5">
                            <img
                                src="assets/images/client/06.jpg"
                                class="h-14 w-14 rounded-full shadow-md mx-auto"
                                alt=""
                            >
                            <h6 class="mt-2 font-semibold">Cristino Murfi</h6>
                            <span class="text-slate-400 text-sm">Manager</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end grid-->
    </div>
    <!--end container-->

    <div class="container relative md:mt-24 mt-16">
        <div class="grid grid-cols-1 text-center">
            <h6 class="text-indigo-600 text-sm font-bold mb-2">Available for freelance projects</h6>
            <h3 class="mb-4 md:text-3xl md:leading-normal text-2xl leading-normal font-semibold">Do you have
                digital project? <br> Let's talk.</h3>

            <p class="text-slate-400 max-w-xl mx-auto">Start working with Techwind that can provide everything
                you need to generate awareness, drive traffic, connect.</p>

            <div class="mt-6">
                <a
                    href="contact-one.html"
                    class="btn bg-indigo-600 hover:bg-indigo-700 border-indigo-600 hover:border-indigo-700 text-white rounded-md mt-4"
                ><i class="uil uil-phone"></i> Contact us</a>
            </div>
        </div>
        <!--end grid-->
    </div>
    <!--end container-->
</section>
<!--end section-->
<!-- End Section-->

<?php echo $_smarty_tpl->getSubTemplate ("front/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>