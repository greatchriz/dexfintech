<?php /* Smarty version 3.1.27, created on 2023-07-09 18:23:01
         compiled from "/home/dexfisce/public_html/images/svg/form/wallet.svg" */ ?>
<?php
/*%%SmartyHeaderCode:136543441264aafb0597f558_52022346%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3cc07be12e8796b5b385534a0156f9381b7b4c6d' => 
    array (
      0 => '/home/dexfisce/public_html/images/svg/form/wallet.svg',
      1 => 1685852704,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '136543441264aafb0597f558_52022346',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aafb05987443_43582110',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aafb05987443_43582110')) {
function content_64aafb05987443_43582110 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '136543441264aafb0597f558_52022346';
?>
<svg
    width="24px"
    height="24px"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    stroke="#9fadc0"
>
    <g
        id="SVGRepo_bgCarrier"
        stroke-width="0"
    ></g>
    <g
        id="SVGRepo_tracerCarrier"
        stroke-linecap="round"
        stroke-linejoin="round"
    ></g>
    <g id="SVGRepo_iconCarrier">
        <g opacity="0.4">
            <path
                d="M8.67188 14.3298C8.67188 15.6198 9.66188 16.6598 10.8919 16.6598H13.4019C14.4719 16.6598 15.3419 15.7498 15.3419 14.6298C15.3419 13.4098 14.8119 12.9798 14.0219 12.6998L9.99187 11.2998C9.20187 11.0198 8.67188 10.5898 8.67188 9.36984C8.67188 8.24984 9.54187 7.33984 10.6119 7.33984H13.1219C14.3519 7.33984 15.3419 8.37984 15.3419 9.66984"
                stroke="#a7b3c5"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
            ></path>
            <path
                d="M12 6V18"
                stroke="#a7b3c5"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
            ></path>
        </g>
        <path
            d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
            stroke="#a7b3c5"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        ></path>
    </g>
</svg>
<?php }
}
?>