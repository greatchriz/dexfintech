<?php /* Smarty version 3.1.27, created on 2023-07-08 12:34:38
         compiled from "my:_emailbody_withdraw_request_admin_notification" */ ?>
<?php
/*%%SmartyHeaderCode:85528977464a957deba0171_34321973%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '004823d1a0d99086909b2972b3c68d0f50283a1f' => 
    array (
      0 => 'my:_emailbody_withdraw_request_admin_notification',
      1 => 1688819678,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '85528977464a957deba0171_34321973',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64a957deba2194_73502935',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64a957deba2194_73502935')) {
function content_64a957deba2194_73502935 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '85528977464a957deba0171_34321973';
?>
User #username# requested to withdraw $#amount# from IP #ip#.<?php }
}
?>