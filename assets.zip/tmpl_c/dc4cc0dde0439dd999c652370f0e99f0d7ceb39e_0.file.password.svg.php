<?php /* Smarty version 3.1.27, created on 2023-07-09 18:23:01
         compiled from "/home/dexfisce/public_html/images/svg/form/password.svg" */ ?>
<?php
/*%%SmartyHeaderCode:60290629364aafb05962941_24070759%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dc4cc0dde0439dd999c652370f0e99f0d7ceb39e' => 
    array (
      0 => '/home/dexfisce/public_html/images/svg/form/password.svg',
      1 => 1685850526,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '60290629364aafb05962941_24070759',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aafb0596a475_57931123',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aafb0596a475_57931123')) {
function content_64aafb0596a475_57931123 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '60290629364aafb05962941_24070759';
?>
<svg
    xmlns="http://www.w3.org/2000/svg"
    class="h-5 w-5 transition-colors duration-200"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
>
    <path
        stroke-linecap="round"
        stroke-linejoin="round"
        stroke-width="1.5"
        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
    ></path>
</svg>
<?php }
}
?>