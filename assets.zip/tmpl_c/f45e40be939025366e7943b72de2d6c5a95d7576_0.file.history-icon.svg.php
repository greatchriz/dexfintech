<?php /* Smarty version 3.1.27, created on 2023-07-09 15:33:59
         compiled from "/home/dexfisce/public_html/images/svg/history-icon.svg" */ ?>
<?php
/*%%SmartyHeaderCode:90137829664aad367344022_79429251%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f45e40be939025366e7943b72de2d6c5a95d7576' => 
    array (
      0 => '/home/dexfisce/public_html/images/svg/history-icon.svg',
      1 => 1686628412,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '90137829664aad367344022_79429251',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aad3673465f5_43451295',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aad3673465f5_43451295')) {
function content_64aad3673465f5_43451295 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '90137829664aad367344022_79429251';
?>
<svg
    class="h-7 w-7"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
>
    <g
        id="SVGRepo_bgCarrier"
        stroke-width="0"
    ></g>
    <g
        id="SVGRepo_tracerCarrier"
        stroke-linecap="round"
        stroke-linejoin="round"
    ></g>
    <g id="SVGRepo_iconCarrier">
        <g id="Menu / Menu_Alt_04">
            <path
                id="Vector"
                d="M5 17H19M5 12H19M5 7H13"
                stroke="#4f46e5"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
            ></path>
        </g>
    </g>
</svg>
<?php }
}
?>