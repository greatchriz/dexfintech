<?php /* Smarty version 3.1.27, created on 2023-07-06 18:16:40
         compiled from "/home/dexfisce/public_html/assets/images/payments/litecoin.svg" */ ?>
<?php
/*%%SmartyHeaderCode:154949085264a7050892e071_32487315%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '34b34e75b3a2c33e8b4732b490b978d945e9dce0' => 
    array (
      0 => '/home/dexfisce/public_html/assets/images/payments/litecoin.svg',
      1 => 1686659302,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '154949085264a7050892e071_32487315',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64a7050892fd48_71894076',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64a7050892fd48_71894076')) {
function content_64a7050892fd48_71894076 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '154949085264a7050892e071_32487315';
?>
<svg
class="inline h-8 w-8 mx-2"
    id="Layer_1"
    data-name="Layer 1"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 82.6 82.6"
>
    <title>litecoin-ltc-logo</title>
    <circle
        cx="41.3"
        cy="41.3"
        r="36.83"
        style="fill:#fff"
    />
    <path
        d="M41.3,0A41.3,41.3,0,1,0,82.6,41.3h0A41.18,41.18,0,0,0,41.54,0ZM42,42.7,37.7,57.2h23a1.16,1.16,0,0,1,1.2,1.12v.38l-2,6.9a1.49,1.49,0,0,1-1.5,1.1H23.2l5.9-20.1-6.6,2L24,44l6.6-2,8.3-28.2a1.51,1.51,0,0,1,1.5-1.1h8.9a1.16,1.16,0,0,1,1.2,1.12v.38L43.5,38l6.6-2-1.4,4.8Z"
        style="fill:#345d9d"
    />
</svg>
<?php }
}
?>