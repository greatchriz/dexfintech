<?php /* Smarty version 3.1.27, created on 2023-07-08 16:31:26
         compiled from "my:_emailbody_registration" */ ?>
<?php
/*%%SmartyHeaderCode:70485890264a98f5ea1db26_87316125%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '349257fbad92bd38ac33c718b057c126817b92e6' => 
    array (
      0 => 'my:_emailbody_registration',
      1 => 1688833886,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '70485890264a98f5ea1db26_87316125',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64a98f5ea861d1_15998316',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64a98f5ea861d1_15998316')) {
function content_64a98f5ea861d1_15998316 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '70485890264a98f5ea1db26_87316125';
?>
Hello #name#,

Thank you for registration on our site.

Your login information:

Login: #username#
Password: #password#

You can login here: #site_url#

Contact us immediately if you did not authorize this registration.

Thank you.<?php }
}
?>