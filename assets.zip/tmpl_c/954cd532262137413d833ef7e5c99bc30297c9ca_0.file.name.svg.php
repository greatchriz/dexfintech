<?php /* Smarty version 3.1.27, created on 2023-07-09 18:23:01
         compiled from "/home/dexfisce/public_html/images/svg/form/name.svg" */ ?>
<?php
/*%%SmartyHeaderCode:190385629464aafb0595c466_71446447%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '954cd532262137413d833ef7e5c99bc30297c9ca' => 
    array (
      0 => '/home/dexfisce/public_html/images/svg/form/name.svg',
      1 => 1685846942,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '190385629464aafb0595c466_71446447',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64aafb0595ee88_77420755',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64aafb0595ee88_77420755')) {
function content_64aafb0595ee88_77420755 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '190385629464aafb0595c466_71446447';
?>
<svg
    xmlns="http://www.w3.org/2000/svg"
    class="h-5 w-5 transition-colors duration-200"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
    stroke-width="1.5"
>
    <path
        stroke-linecap="round"
        stroke-linejoin="round"
        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
    />
</svg>
<?php }
}
?>