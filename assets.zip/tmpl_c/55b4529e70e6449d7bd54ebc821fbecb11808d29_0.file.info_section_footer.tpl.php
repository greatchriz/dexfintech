<?php /* Smarty version 3.1.27, created on 2023-07-06 18:16:40
         compiled from "/home/dexfisce/public_html/tmpl/info_section_footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:200058572064a705088a45d8_15069715%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '55b4529e70e6449d7bd54ebc821fbecb11808d29' => 
    array (
      0 => '/home/dexfisce/public_html/tmpl/info_section_footer.tpl',
      1 => 1687587522,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '200058572064a705088a45d8_15069715',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_64a705088a5822_46037591',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_64a705088a5822_46037591')) {
function content_64a705088a5822_46037591 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '200058572064a705088a45d8_15069715';
?>

</div>



</div>
<!--end grid-->

</div>
<!--end container-->

</section>
<!--end section-->
<?php }
}
?>